<?php
// echo 'home.php';exit;
$smarty->display('index.html');