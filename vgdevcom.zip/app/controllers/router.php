<?php

require $_SERVER['DOCUMENT_ROOT'].'/vendor/autoload.php';
// require '../vendor/autoload.php'; //localhost

$router = new AltoRouter();

$router->setBasePath('');
// $router->setBasePath('/vgdevcom');

$smarty = new Smarty();

$router->map('GET', '/', function() use ($smarty) {
    $smarty->setTemplateDir('../app/views/client');
    $smarty->setCompileDir('../cache/');
    require('../app/controllers/client/home.php');
});

$router->map('GET', '/admin', function() use ($smarty) {
    $smarty->setTemplateDir('../app/views/admin');
    $smarty->setCompileDir('../cache/');
    require('../app/controllers/admin/home.php');
});

$match = $router->match();

if ($match && is_callable($match['target'])) {
    call_user_func_array($match['target'], $match['params']);
} else {
    header($_SERVER["SERVER_PROTOCOL"] . ' 404 Not Found');
}