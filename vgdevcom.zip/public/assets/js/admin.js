console.log('Hello, Admin!');
