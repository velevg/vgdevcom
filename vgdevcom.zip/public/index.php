<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once('../vendor/autoload.php' );
require_once('../vendor/smarty/smarty/libs/Smarty.class.php' );
require_once('../app/controllers/router.php' );
// echo "loal";

// $smarty = new Smarty();

// Check if the server name or host contains 'localhost'
$isLocalhost = (strpos($_SERVER['SERVER_NAME'], 'localhost') !== false || strpos($_SERVER['HTTP_HOST'], 'localhost') !== false);

// Define the root path of the app
$rootPath = $isLocalhost ? __DIR__ . '/..' : __DIR__ . '/../..';  // Adjust the path based on localhost or server

// Define the public path
$publicPath = $isLocalhost ? $rootPath : $rootPath . '/public';  // Adjust the path based on localhost or server

// Define the assets path
$assetsPath = $publicPath . '/assets';

if ($isLocalhost) {
    echo "Running on localhost";
} else {
    echo "Running on a server";
}
echo"<br>";
// Example usage:
echo "Root path of the app: $rootPath<br>";
echo "Public path: $publicPath<br>";
echo "Assets path: $assetsPath<br>";