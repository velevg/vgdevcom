<?php
/* Smarty version 4.3.4, created on 2024-02-04 19:55:57
  from '/opt/lampp/htdocs/vgdevcom/app/views/admin/index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65bfddbdee7624_86036410',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '87f604848e38f3e2f675b9ae91051d69696893de' => 
    array (
      0 => '/opt/lampp/htdocs/vgdevcom/app/views/admin/index.html',
      1 => 1707072954,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65bfddbdee7624_86036410 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <link rel="stylesheet" href="/vgdevcom/public/assets/css/style.css">
    <?php echo '<script'; ?>
 src="/vgdevcom/public/assets/js/script.js"><?php echo '</script'; ?>
>
</head>
<body>
    admin
</body>
</html><?php }
}
